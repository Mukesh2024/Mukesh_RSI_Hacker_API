export interface StoryModel{
    Title:string;
    NewsArticle:string;
}