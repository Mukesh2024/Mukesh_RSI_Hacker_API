﻿namespace HackerAPI.Models
{
    public class HackerApiSettings
    {
        public string BaseApiUrl { get; set; }
    }
}
