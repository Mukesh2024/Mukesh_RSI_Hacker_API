﻿namespace HackerAPI
{
    public class StoryDetail
    {
        public string? Title { get; set; }
        public string? NewsArticle { get; set; }
    }
}
